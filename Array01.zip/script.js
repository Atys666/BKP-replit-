//VARIAVEIS UNITARIAS
const nome = 'Atys';
const nome2 = 'Pink';
const nome3 = 'Guaxuxu';




//VARIAVEIS DE ARRAY
const nomes = ['Atys', 'Pink', 'Guaxuxu'];
console.log(nomes)
console.log(nomes[2])
nomes[10] = "guaxinimins" // CRIANDO DINAMICAMENTE
console.log(nomes[10])